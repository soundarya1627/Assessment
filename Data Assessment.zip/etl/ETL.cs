using Xunit;

namespace demo;

public class ETL
{
    string stores_file = "../../../data/dim_stores.csv";

    string countries_file = "../../../data/dim_countries.csv";
    Dictionary<string, string> countries = new Dictionary<string, string>();

    public ETL() {
        var dimCountries = DimCountry.ExtractFromCsv(countries_file);

        foreach(var country in dimCountries) {
            Assert.True(country.country_code != null, "Null country code found");
            Assert.True(country.country_name != null);
            this.countries[country.country_code] = country.country_name;
        }
    }

    private static string FirstCharToUpper(string s)  
    {  
        // Check for empty string.  
        if (string.IsNullOrEmpty(s))  
        {  
        return string.Empty;  
        }  
        // Return char and concat substring.  
        return char.ToUpper(s[0]) + s.Substring(1);  
    }


    private bool isProperCountryName(string name)
    {
        return name == FirstCharToUpper(name);
    }
    
    [Fact]
    public void TestCountryName() {
        List<DimStore> dimStores = DimStore.ExtractFromCsv(stores_file);

        foreach(var dimStore in dimStores) {
            Assert.True(dimStore.country_code != null);
            var country_name = countries[dimStore.country_code];
            Assert.True(isProperCountryName(country_name), "Invalid Countyr Name Found: " + country_name);
            dimStore.is_automatable = true;
        } 
        return;
    }
}