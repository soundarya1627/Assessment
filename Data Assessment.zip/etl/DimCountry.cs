using System.Text.RegularExpressions;

namespace demo;

class DimCountry {
    public int country_id;
    public string? country_code;
    public string? country_name;

    public static DimCountry FromCsv(string csvLine) {
        Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
        string[] values = CSVParser.Split(csvLine);
        DimCountry country = new DimCountry();
        country.country_id = Convert.ToInt32(values[0]);
        country.country_code = values[1];
        country.country_name = values[2];

        return country;
    }

    public static List<DimCountry> ExtractFromCsv(string fileName) 
    {
        List<DimCountry> dimCountries = new List<DimCountry>();

        var lines = File.ReadLines(fileName);
        foreach (var line in lines.Skip(1)) {
            dimCountries.Add(FromCsv(line));
        }

        return dimCountries;
    }

}