using Xunit;
using Newtonsoft.Json;

namespace demo;

public class REST
{
    private string api_key = "4e9edcd662msh855a642175b307fp1cd6bajsn9de5e33d5b7c";

    private string world_data_uri = "https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/npm-covid-data/world";

    private string invalid_endpoint_uri = "https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/npm-covid-data/invalid_endpoint";

    [Fact]
    public async Task TestVacCovidWorldDataApiAsync()
    {
        using (var response = await VacCovid.GetVacCovidAsync(api_key, world_data_uri))
        {
            // Case 1: Ensures success code recived from the responce, otherwise will throw an exception
            response.EnsureSuccessStatusCode(); 
            
            var body = await response.Content.ReadAsStringAsync();

            // Case 2: Ensures body in Json format otherwise throws an exception.
            Assert.True(body != null);
            // Case 4: Json format is performed by DeserializeObject()
            dynamic json = JsonConvert.DeserializeObject(body);
            Console.WriteLine(json);

            // Case 3: Checking World Data recived from the tests
            Assert.True(json[0]["Country"] == "World");
        }
    }

    [Fact]
    public async Task TestVacCovidWorldDataApiInvalidEndPointAsync()
    {
        using (var response = await VacCovid.GetVacCovidAsync(api_key, invalid_endpoint_uri)) {

            Console.WriteLine("TestVacCovidWorldDataApiInvalidEndPointAsync: ");

            //Case1: should not get the success responce
            Assert.False(response.IsSuccessStatusCode);
            var body = await response.Content.ReadAsStringAsync();
            Console.WriteLine(body);


            //Case2: should get status code as 404
            Console.WriteLine(response.StatusCode);
            Assert.True(response.StatusCode == System.Net.HttpStatusCode.NotFound);
        }
    }

    [Fact(Skip = "VacCovid accepting invalid authorization keys, need to be fixed")]
    public async Task TestVacCovidWorldDataApiInvalidApiKeyAsync()
    {
        using (var response = await VacCovid.GetVacCovidAsync("INVALID_KEY", world_data_uri)) {
            //Case1: should not get the success responce
            Assert.False(response.IsSuccessStatusCode);
            //Case2: should get status code as 401
            Assert.True(response.StatusCode == System.Net.HttpStatusCode.Unauthorized);
        }
    }
}