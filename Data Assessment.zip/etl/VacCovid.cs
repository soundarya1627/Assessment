namespace demo;


public class VacCovid
{
    static public async Task<HttpResponseMessage> GetVacCovidAsync(string api_key, string uri) {
        var client = new HttpClient();
        var request = new HttpRequestMessage
        {
            Method = HttpMethod.Get,
            RequestUri = new Uri(uri),
            Headers =
            {
                { "X-RapidAPI-Key", api_key },
                { "X-RapidAPI-Host", "vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com" },
            },
        };


        var response = await client.SendAsync(request);
        return response;
    }
}
