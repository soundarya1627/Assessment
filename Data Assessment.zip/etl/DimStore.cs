using System.Text.RegularExpressions;

namespace demo;

public class DimStore {

    public int store_id;
    public string? store_code;
    public string? store_name;
    public string? country_code;
    public string? street_name;
    public uint pin_code;
    public string? lvl1_geog;
    public string? lvl2_goeg;
    public string? lvl3_geog;

    public bool is_automatable = false;

    public static DimStore FromCsv(string csvLine)
    {
        Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
        string[] values = CSVParser.Split(csvLine);
        DimStore dimStore = new DimStore();
        dimStore.store_id = Convert.ToInt32(values[0]);
        dimStore.store_code = values[1];
        dimStore.store_name = values[2];
        dimStore.country_code = values[3];
        dimStore.street_name = values[4];
        dimStore.pin_code = Convert.ToUInt32(values[5]);
        dimStore.lvl1_geog = values[6];
        dimStore.lvl2_goeg = values[7];
        dimStore.lvl3_geog = values[8];
        return dimStore;
    }

    public static List<DimStore> ExtractFromCsv(string fileName) 
    {
        List<DimStore> dimStores = new List<DimStore>();

        var lines = File.ReadLines(fileName);
        foreach (var line in lines.Skip(1)) {
            dimStores.Add(FromCsv(line));
        }

        return dimStores;
    }

}